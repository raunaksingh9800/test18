congrats on makinggggggg ittttttt sooooooooooo farrrrrrrrrrrrrr
now c one is easy you have to figure it out and tell me the syntax type

the run command for the main.c is love 

gcc main.c -o m && m but u can always use online complier