#include <stdio.h>

#define __ 4
#define __1 2

int main() {
    int _[__];
    0[_] = 3;
    int *____p = _;          
    int **__p__ = &____p;     
    *(*__p__ + __1) = 32;
    printf("%d\n", *(__1 + *__p__));
    printf("%d\n", 0[_]);
    return 0;
}