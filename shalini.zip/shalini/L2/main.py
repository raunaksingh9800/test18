rent_price_y_axis = [
1e4, ## so love in computer when u wanna write (1x10^3) u write it as 1e3
1.4e4, ## 1.4 x 10^4 = 14000  
1.6e4,
1.8e4,
2.2e4,
2.5e4,
]

time_line_x_axis = [
1 , 2, 3 , 4 , 5 , 6
]

a, b = 0

## so we are gonna use a model to pridect future rent prices . Kissie

## visit : https://hosting-space.vercel.app/test54 for all guide

## Part 1 goes below

## part 2 goes below

## part 3 goes below

## part 4 goes below






