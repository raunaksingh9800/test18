hello love welcome to level 2

here we deal with python more like data and errors
now love the code has some error please check it and fix it


