Welcome Shalini 

Rules:
1. Use terminal only.
2. Read carefully.
3. Think before running.


ENTRY : start_here.txt
