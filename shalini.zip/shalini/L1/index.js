// Hey Shalini welcome to JS

// This is to import readline to read your answer
const readline = require("readline");
// this is to hash the answer
const crypto = require("crypto");

// this is to get the input interface ready
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

// THE GOLD
const hashedAns =
  "1785cfc3bc6ac7738e8b38cdccd1af12563c2b9070e07af336a1bf8c0f772b6a";
// This is the hashed Answer to the question

/*
-- FUN FACT
hashing is one way so if you take that string and put it in chatGPT 
it wont give you the answer
*/

// this is my secret to verfiy u have guessed it correct
const SECRET_SALT = "only_raunak_knows_this"


rl.question("What is one thing i hate about you (one word) ? ", (answer) => {
  /* 
    Now love Hashing is one way so we need to hash you ans 
    and compare it with the my hashed answer */
  const inputHash = crypto
    .createHash("sha256")
    .update(answer.toLowerCase().trim())
    .digest("hex");

  // Just logical Checks
  if (inputHash === hashedAns) {

    // genereate the verfication code love
    const verificationCode = crypto
      .createHash("sha256")
      .update(answer + SECRET_SALT)
      .digest("hex")
      .slice(0, 6);

      console.log("Correct. please pls Proceed to ../level_2/");
    console.log("Your verification code:", verificationCode);

  } else {
    console.log("Hmm. Think deeper.\n-> Checkout index.js");
  }
  rl.close();
});
