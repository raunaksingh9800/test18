hey shalini

this level very simple no worriesss
all you go to do is open this folder in you cmd and run
node index.js and if unable to run check start_here bottom

and dont forget to check the code 